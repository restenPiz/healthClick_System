
<img src="./assets/ss.png" style="height: 3rem"><?php /**PATH C:\Herd\healthClick_System\resources\views/components/application-logo.blade.php ENDPATH**/ ?>