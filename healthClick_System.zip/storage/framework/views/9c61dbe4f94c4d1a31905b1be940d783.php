<div>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Delivery')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-8">
        
            <div class="grid gap-6 md:grid-cols-3">
                <div>
                    <select id="countries" wire:model.live="status"  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <option value="">Select the option</option>
                        <option value="pendente">Pendente</option>
                        <option value="entregue">Entregue</option>
                    </select>
                </div>
                
            </div>
        
    </div>
    
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-8">
        <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
            
            <?php if (isset($component)) { $__componentOriginala665a74688c74e9ee80d4fedd2b98434 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala665a74688c74e9ee80d4fedd2b98434 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-message','data' => ['class' => 'me-3 bg-green-700 rounded text-white dark:text-white','on' => 'delivery-updated']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-3 bg-green-700 rounded text-white dark:text-white','on' => 'delivery-updated']); ?>
                <?php echo e(__('Product successfully delivered')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $attributes = $__attributesOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $component = $__componentOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__componentOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
            
            <div style="margin-top:0.5rem"></div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white dark:bg-gray-900 rounded-xl shadow-md p-6 border border-gray-200 dark:border-gray-700">
                    <h3 class="text-lg font-bold text-gray-800 dark:text-white">DELIVERY CODE DV<?php echo e($delivery->id); ?></h3>
                    <p class="mt-2 text-sm text-gray-600 dark:text-gray-300">
                       Owner: <?php echo e($delivery->sale->user->name); ?>

                    </p>
                    <p class="mt-2 text-sm text-gray-600 dark:text-gray-300">
                       Owner Email: <?php echo e($delivery->sale->user->email); ?>

                    </p>
                    <p class=" mt-2 text-sm text-gray-600 dark:text-gray-300">
                        Location: <?php echo e($delivery->delivery_address); ?>

                    </p>
                    <p class="mt-2 text-sm text-gray-600 dark:text-gray-300">
                        Contact: +258 <?php echo e($delivery->contact); ?>

                    </p>
                    <p class="mt-2 text-sm text-gray-600 dark:text-gray-300">
                        Status: <!--[if BLOCK]><![endif]--><?php if($delivery->status=='pendente'): ?>
                        <span style="color:yellow"><?php echo e($delivery->status); ?></span>
                        <?php else: ?>
                        <span style="color:green"><?php echo e($delivery->status); ?></span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </p>
                    <div class=" mt-4 flex items-center space-x-4">
                        
                         <!--[if BLOCK]><![endif]--><?php if($delivery->status=='entregue'): ?>

                         <?php else: ?>
                        <button wire:click="confirmDelivery(<?php echo e($delivery->id); ?>)"
                            class="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                            Confirm
                        </button>
                         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div><br><br>
</div>
<?php /**PATH C:\Herd\healthClick_System\resources\views/livewire/delivery.blade.php ENDPATH**/ ?>