

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['on']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['on']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div 
    x-data="{ shown: false, timeout: null }"
    x-init="window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('<?php echo e($on); ?>', () => { clearTimeout(timeout); shown = true; timeout = setTimeout(() => { shown = false }, 3000); })"
    x-show.transition.out.opacity.duration.1000ms="shown"
    x-transition:leave.opacity.duration.1000ms
    style="display: none;"
    <?php echo e($attributes->merge(['class' => 'flex items-center gap-3 px-4 py-3 rounded-md bg-green-100 border border-green-300 text-green-800 shadow-lg'])); ?>

>
    
    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
    </svg>

    
    <span class="text-sm font-medium">
        <?php echo e($slot->isEmpty() ? __('Saved.') : $slot); ?>

    </span>
</div><?php /**PATH C:\Herd\healthClick_System\resources\views/components/action-message.blade.php ENDPATH**/ ?>